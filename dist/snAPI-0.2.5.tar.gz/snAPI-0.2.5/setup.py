from setuptools import setup, find_packages
from setuptools.dist import Distribution
from distutils.command.build import build as _build

class build(_build):
    def run(self):
        self.run_command("build_ext")
        _build.run(self)

class BinaryDistribution(Distribution):
    def has_ext_modules(self):
        return True

setup(
    name="snAPI",
    version="0.2.5", # also change resource.h !!!
    packages=['snAPI'],
    include_package_data=True,
    zip_safe=False,
    install_requires=["numpy", "typing"],
    entry_points={
        'console_scripts': [
            'my_command=snAPI.Main:snAPI',
        ],
    },
    setup_requires=["wheel"],
    package_data={"snAPI": ["*.dll",
                            "*.ini",
                            ]},
    distclass=BinaryDistribution,
    cmdclass={"build": build},
)

# clean delete snAPI.egg-inf, build, dist
# python -m build --sdist --wheel
# pip install .\dist\snAPI-0.1.0-cp311-cp311-win_amd64.whl --force-reinstall